import React from 'react';
import { StagingSimulator, CommitGraphVisualizer, TerminalSimulator } from '../simulators';

export default function PracticeTab({ practice, color, chapterId }) {
  // Route specific chapters to their dedicated simulators
  if (chapterId === 4)            return <StagingSimulator color={color} />;
  if (chapterId === 8 || chapterId === 9) return <CommitGraphVisualizer color={color} />;
  if (chapterId === 5 || chapterId === 6) return <TerminalSimulator color={color} />;

  // Generic step-by-step practice + terminal for everything else
  return (
    <div>
      {practice?.steps?.length > 0 && (
        <div style={{ marginBottom: 32 }}>
          <h3 style={{
            fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700,
            color: 'var(--text-primary)', marginBottom: 16,
          }}>⚡ Practice Exercise</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {practice.steps.map((step, i) => (
              <div key={i} style={{
                background: 'var(--bg-elevated)',
                border: '1px solid var(--border)',
                borderRadius: 'var(--radius-lg)',
                padding: '18px 20px',
                display: 'flex', gap: 14, alignItems: 'flex-start',
                animation: 'fadeInUp 0.3s ease',
                animationDelay: `${i * 80}ms`,
                animationFillMode: 'both',
              }}>
                <div style={{
                  width: 28, height: 28, borderRadius: '50%',
                  background: `${color}28`, color,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: 'var(--font-mono)', fontWeight: 700,
                  fontSize: 13, flexShrink: 0,
                }}>{i + 1}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ color: 'var(--text-primary)', fontWeight: 600, marginBottom: 5, fontSize: 14 }}>
                    {step.title}
                  </div>
                  <p style={{ color: 'var(--text-secondary)', fontSize: 14, lineHeight: 1.6, marginBottom: step.command ? 10 : 0 }}>
                    {step.desc}
                  </p>
                  {step.command && (
                    <code style={{
                      display: 'inline-block',
                      background: 'var(--bg-card)',
                      border: '1px solid var(--border)',
                      borderRadius: 'var(--radius-sm)',
                      padding: '4px 12px',
                      color, fontFamily: 'var(--font-mono)', fontSize: 13,
                    }}>{step.command}</code>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Always provide a terminal at the bottom for practice */}
      <TerminalSimulator color={color} />
    </div>
  );
}
