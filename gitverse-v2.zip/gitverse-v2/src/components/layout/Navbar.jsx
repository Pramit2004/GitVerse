import React from 'react';
import { useApp } from '../../context/AppContext';
import { ProgressRing } from '../ui';
import { useIsMobile } from '../../hooks';

export default function Navbar({ readingProgress = 0 }) {
  const {
    activeChapter, view,
    goHome, setView,
    sidebarOpen, setSidebarOpen,
    searchOpen, setSearchOpen,
    completedCount, progressPct,
  } = useApp();

  const isMobile = useIsMobile();
  const isChapterView = view === 'chapter' && activeChapter;

  return (
    <>
      {/* Reading progress bar */}
      {isChapterView && readingProgress > 0 && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, height: 3,
          zIndex: 201, background: 'var(--border)',
        }}>
          <div style={{
            height: '100%',
            width: `${readingProgress}%`,
            background: `linear-gradient(90deg, ${activeChapter.color}, var(--blue))`,
            transition: 'width 0.1s linear',
            boxShadow: `0 0 8px ${activeChapter.color}60`,
          }} />
        </div>
      )}

      <nav style={{
        position: 'sticky', top: 0, zIndex: 100,
        background: 'rgba(10,14,26,0.96)',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        borderBottom: '1px solid var(--border)',
        padding: '0 24px',
      }}>
        <div style={{
          maxWidth: 'var(--page-max)', margin: '0 auto',
          display: 'flex', alignItems: 'center',
          justifyContent: 'space-between',
          height: 'var(--nav-height)',
          gap: 12,
        }}>
          {/* Logo */}
          <button
            onClick={goHome}
            aria-label="GitVerse home"
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0,
            }}>
            <span style={{ fontSize: 22 }}>⚡</span>
            <span style={{
              fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 900,
              color: 'var(--green)', letterSpacing: -0.5,
            }}>GitVerse</span>
          </button>

          {/* Chapter breadcrumb (desktop only) */}
          {isChapterView && !isMobile && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 8,
              overflow: 'hidden', flex: 1, minWidth: 0,
            }}>
              <span style={{ color: 'var(--text-muted)', fontSize: 13 }}>›</span>
              <span style={{
                color: activeChapter.color,
                fontFamily: 'var(--font-mono)', fontSize: 12,
                background: activeChapter.color + '20',
                padding: '2px 8px', borderRadius: 20,
                flexShrink: 0,
              }}>Ch. {activeChapter.id}</span>
              <span style={{
                color: 'var(--text-secondary)', fontSize: 13,
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}>
                {activeChapter.title}
              </span>
            </div>
          )}

          {/* Right controls */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
            {/* Search button */}
            <button
              onClick={() => setSearchOpen(true)}
              aria-label="Search"
              title="Search (Press /)"
              style={{
                background: 'var(--bg-elevated)', border: '1px solid var(--border)',
                color: 'var(--text-muted)', borderRadius: 'var(--radius-md)',
                padding: isMobile ? '6px 10px' : '6px 14px',
                fontFamily: 'var(--font-mono)', fontSize: 12, cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 6,
                transition: 'all var(--transition-fast)',
              }}>
              <span>🔍</span>
              {!isMobile && <span>Search</span>}
              {!isMobile && (
                <span style={{
                  background: 'var(--bg-card)', border: '1px solid var(--border-bright)',
                  borderRadius: 4, padding: '0 5px', fontSize: 10,
                  color: 'var(--text-muted)',
                }}>/</span>
              )}
            </button>

            {/* Chapters button */}
            <button
              onClick={() => setView('all-chapters')}
              style={{
                background: view === 'all-chapters' ? 'var(--bg-card)' : 'transparent',
                border: '1px solid var(--border)',
                color: 'var(--text-secondary)', borderRadius: 'var(--radius-md)',
                padding: '6px 14px', cursor: 'pointer',
                fontFamily: 'var(--font-mono)', fontSize: 12,
                display: isMobile ? 'none' : 'block',
              }}>
              Chapters
            </button>

            {/* Cheatsheet button */}
            <button
              onClick={() => setView('cheatsheet')}
              style={{
                background: view === 'cheatsheet' ? 'var(--bg-card)' : 'transparent',
                border: '1px solid var(--border)',
                color: 'var(--text-secondary)', borderRadius: 'var(--radius-md)',
                padding: '6px 14px', cursor: 'pointer',
                fontFamily: 'var(--font-mono)', fontSize: 12,
                display: isMobile ? 'none' : 'block',
              }}>
              Cheatsheet
            </button>

            {/* Progress indicator */}
            <div
              style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}
              onClick={() => setView('all-chapters')}
              title={`${completedCount} of 18 chapters complete`}
            >
              <ProgressRing progress={progressPct} size={34} />
            </div>

            {/* Sidebar toggle (chapter view) */}
            {isChapterView && (
              <button
                onClick={() => setSidebarOpen(v => !v)}
                aria-label="Toggle chapter menu"
                style={{
                  background: sidebarOpen ? 'var(--green-glow)' : 'var(--bg-elevated)',
                  border: `1px solid ${sidebarOpen ? 'rgba(0,255,136,0.3)' : 'var(--border)'}`,
                  color: sidebarOpen ? 'var(--green)' : 'var(--text-secondary)',
                  borderRadius: 'var(--radius-md)', padding: '6px 12px',
                  cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 13,
                }}>
                ☰
              </button>
            )}

            {/* Mobile hamburger (non-chapter) */}
            {!isChapterView && isMobile && (
              <button
                onClick={() => setView('all-chapters')}
                style={{
                  background: 'var(--bg-elevated)', border: '1px solid var(--border)',
                  color: 'var(--text-secondary)', borderRadius: 'var(--radius-md)',
                  padding: '6px 12px', cursor: 'pointer', fontSize: 15,
                }}>
                ☰
              </button>
            )}
          </div>
        </div>
      </nav>
    </>
  );
}
