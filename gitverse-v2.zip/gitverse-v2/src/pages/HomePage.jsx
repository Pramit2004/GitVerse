import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { CHAPTERS, PARTS, COMMAND_REFERENCE } from '../data/chapters';
import { ProgressRing, AnimatedCounter } from '../components/ui';

/* ── Hero Terminal ───────────────────────────────────── */
function HeroTerminal() {
  const lines = [
    { cmd: 'git init',                                    out: 'Initialized empty Git repository in /my-project/.git/', delay: 300 },
    { cmd: 'git add .',                                   out: null, delay: 1100 },
    { cmd: 'git commit -m "Start learning Git 🚀"',       out: '[main a1b2c3d] Start learning Git 🚀\n 1 file changed, 42 insertions(+)', delay: 2000 },
    { cmd: 'git branch feature/build-something-great',   out: null, delay: 3200 },
    { cmd: 'git switch feature/build-something-great',   out: "Switched to branch 'feature/build-something-great'", delay: 4100 },
    { cmd: 'git log --oneline',                          out: 'a1b2c3d (HEAD -> feature/build-something-great, main) Start learning Git 🚀', delay: 5100 },
  ];

  return (
    <div style={{
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-bright)',
      borderRadius: 14,
      overflow: 'hidden',
      boxShadow: '0 24px 64px rgba(0,0,0,0.6), 0 0 0 1px rgba(0,255,136,0.05)',
      maxWidth: 560, width: '100%',
    }}>
      {/* Title bar */}
      <div style={{
        background: 'var(--bg-card)', padding: '10px 16px',
        display: 'flex', alignItems: 'center', gap: 8,
        borderBottom: '1px solid var(--border)',
      }}>
        {['#ff5f56', '#ffbd2e', '#27c93f'].map(c => (
          <div key={c} style={{ width: 12, height: 12, borderRadius: '50%', background: c }} />
        ))}
        <span style={{ marginLeft: 8, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: 12 }}>
          ~/my-project — bash
        </span>
      </div>
      {/* Body */}
      <div style={{ padding: '20px 20px 24px', minHeight: 220 }}>
        {lines.map((line, i) => (
          <TerminalLine key={i} command={line.cmd} output={line.out} delay={line.delay} />
        ))}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 8 }}>
          <span style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: 13 }}>$</span>
          <span style={{
            width: 8, height: 16, background: 'var(--green)',
            display: 'inline-block', marginLeft: 2,
            animation: 'blink 1s step-end infinite',
          }} />
        </div>
      </div>
    </div>
  );
}

function TerminalLine({ command, output, delay }) {
  const [visible, setVisible]       = useState(false);
  const [showOutput, setShowOutput] = useState(false);
  useEffect(() => {
    const t1 = setTimeout(() => setVisible(true), delay);
    const t2 = setTimeout(() => setShowOutput(true), delay + 600);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [delay]);
  return (
    <div style={{ marginBottom: 6, opacity: visible ? 1 : 0, transition: 'opacity 0.3s' }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <span style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: 13 }}>$</span>
        <span style={{ color: 'var(--green)', fontFamily: 'var(--font-mono)', fontSize: 13 }}>{command}</span>
      </div>
      {output && showOutput && (
        <div style={{
          marginLeft: 20, color: 'var(--text-secondary)',
          fontFamily: 'var(--font-mono)', fontSize: 12,
          marginTop: 2, whiteSpace: 'pre', animation: 'fadeIn 0.3s ease',
        }}>{output}</div>
      )}
    </div>
  );
}

/* ── Keyboard shortcut hint ──────────────────────────── */
function ShortcutHint({ keys, label }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: 'var(--text-muted)', fontSize: 12 }}>
      {keys.map(k => (
        <kbd key={k} style={{
          background: 'var(--bg-card)', border: '1px solid var(--border-bright)',
          borderRadius: 4, padding: '1px 6px',
          fontFamily: 'var(--font-mono)', fontSize: 11,
        }}>{k}</kbd>
      ))}
      <span>{label}</span>
    </span>
  );
}

/* ── HomePage ────────────────────────────────────────── */
export default function HomePage() {
  const { openChapter, progress, completedCount, progressPct, setView } = useApp();
  const [cmdTab, setCmdTab] = useState(0);

  const nextChapter = CHAPTERS.find(c => !progress[c.id]);

  return (
    <div>
      {/* ── HERO ─────────────────────────────────────── */}
      <section style={{
        minHeight: 'calc(100vh - var(--nav-height))',
        display: 'flex', alignItems: 'center',
        padding: 'clamp(32px,6vw,80px) clamp(16px,4vw,48px)',
        maxWidth: 'var(--page-max)', margin: '0 auto',
        gap: 'clamp(32px, 5vw, 64px)',
        flexWrap: 'wrap',
      }}>
        {/* Left copy */}
        <div style={{ flex: '1 1 340px', minWidth: 0 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            background: 'var(--green-glow)',
            border: '1px solid rgba(0,255,136,0.25)',
            borderRadius: 20, padding: '5px 14px', marginBottom: 20,
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--green)', animation: 'pulseGreen 2s infinite' }} />
            <span style={{ color: 'var(--green)', fontFamily: 'var(--font-mono)', fontSize: 12 }}>
              18 chapters · Free · No signup
            </span>
          </div>

          <h1 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(36px, 6vw, 68px)',
            fontWeight: 900, lineHeight: 1.05,
            marginBottom: 20,
          }}>
            Master{' '}
            <span style={{
              background: 'linear-gradient(135deg, var(--green), var(--blue))',
              backgroundSize: '200% 200%',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              animation: 'gradientShift 4s ease infinite',
            }}>Git &</span>
            <br />
            <span style={{
              background: 'linear-gradient(135deg, var(--blue), var(--purple))',
              backgroundSize: '200% 200%',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              animation: 'gradientShift 4s ease infinite',
            }}>GitHub</span>
          </h1>

          <p style={{
            color: 'var(--text-secondary)', fontSize: 'clamp(15px,2vw,18px)',
            lineHeight: 1.75, marginBottom: 32, maxWidth: 500,
          }}>
            The world's most complete Git guide. 18 deep chapters, interactive simulators,
            real-world projects. Built for <em>real understanding</em> — not memorization.
          </p>

          {/* CTA Buttons */}
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 28 }}>
            <button
              onClick={() => openChapter(nextChapter || CHAPTERS[0])}
              style={{
                background: 'var(--green)', color: '#000',
                border: 'none', borderRadius: 10, padding: '14px 28px',
                fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 700,
                cursor: 'pointer', animation: 'pulseGreen 3s infinite',
                transition: 'transform 0.15s',
              }}
              onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.03)'}
              onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
            >
              {completedCount > 0 ? `Continue (Ch. ${nextChapter?.id || 1}) →` : 'Start Learning →'}
            </button>
            <button
              onClick={() => setView('all-chapters')}
              style={{
                background: 'transparent', color: 'var(--blue)',
                border: '1px solid var(--blue-dim)', borderRadius: 10, padding: '14px 22px',
                fontFamily: 'var(--font-mono)', fontSize: 14, cursor: 'pointer',
                transition: 'all 0.15s',
              }}
              onMouseEnter={e => { e.currentTarget.style.background = 'rgba(77,171,247,0.08)'; }}
              onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
            >
              Browse All Chapters
            </button>
          </div>

          {/* Keyboard hints */}
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            <ShortcutHint keys={['/']} label="to search" />
            <ShortcutHint keys={['J', 'K']} label="to navigate" />
          </div>

          {/* Stats */}
          <div style={{ display: 'flex', gap: 36, marginTop: 36 }}>
            {[
              { label: 'Chapters', value: 18 },
              { label: 'Commands', value: 60, suffix: '+' },
              { label: 'Simulators', value: 4 },
            ].map(s => (
              <div key={s.label}>
                <div style={{
                  fontFamily: 'var(--font-display)', fontSize: 'clamp(26px,3vw,36px)',
                  fontWeight: 900, color: 'var(--green)', lineHeight: 1,
                }}>
                  <AnimatedCounter value={s.value} suffix={s.suffix || ''} />
                </div>
                <div style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: 11, marginTop: 3 }}>
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Terminal */}
        <div style={{
          flex: '0 1 520px',
          display: 'flex', justifyContent: 'center',
          animation: 'float 5s ease-in-out infinite',
        }}>
          <HeroTerminal />
        </div>
      </section>

      {/* ── PROGRESS BANNER (if started) ─────────────── */}
      {completedCount > 0 && (
        <div style={{
          background: 'var(--bg-surface)',
          borderTop: '1px solid var(--border)',
          borderBottom: '1px solid var(--border)',
          padding: '20px clamp(16px,4vw,48px)',
        }}>
          <div style={{ maxWidth: 'var(--page-max)', margin: '0 auto', display: 'flex', alignItems: 'center', gap: 20, flexWrap: 'wrap' }}>
            <ProgressRing progress={progressPct} size={52} />
            <div>
              <div style={{ color: 'var(--text-primary)', fontWeight: 600, fontSize: 15 }}>
                Your Progress — {completedCount} of {CHAPTERS.length} chapters complete
              </div>
              <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>
                {nextChapter ? `Next up: ${nextChapter.emoji} ${nextChapter.title}` : '🎉 All chapters complete! You\'re a Git master.'}
              </div>
            </div>
            {nextChapter && (
              <button
                onClick={() => openChapter(nextChapter)}
                style={{
                  marginLeft: 'auto', background: 'var(--green)', color: '#000',
                  border: 'none', borderRadius: 8, padding: '10px 20px',
                  fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 700, cursor: 'pointer',
                }}>
                Continue →
              </button>
            )}
          </div>
        </div>
      )}

      {/* ── PARTS OVERVIEW ───────────────────────────── */}
      <section style={{
        padding: 'clamp(40px,6vw,80px) clamp(16px,4vw,48px)',
        background: 'var(--bg-surface)',
        borderBottom: '1px solid var(--border)',
      }}>
        <div style={{ maxWidth: 'var(--page-max)', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(26px,4vw,40px)', fontWeight: 900, marginBottom: 10 }}>
              The Complete Journey
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: 15 }}>
              Six parts. 18 chapters. Everything there is to know about Git.
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
            gap: 16,
          }}>
            {PARTS.map(part => {
              const partChapters = CHAPTERS.filter(c => part.chapters.includes(c.id));
              const done = partChapters.filter(c => progress[c.id]).length;
              const pct  = Math.round((done / partChapters.length) * 100);
              return (
                <div
                  key={part.id}
                  style={{
                    background: 'var(--bg-card)',
                    border: `1px solid ${done === partChapters.length ? part.color + '40' : 'var(--border)'}`,
                    borderRadius: 'var(--radius-xl)',
                    padding: 22, cursor: 'pointer',
                    transition: 'all var(--transition-base)',
                  }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = part.color + '60'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = done === partChapters.length ? part.color + '40' : 'var(--border)'; e.currentTarget.style.transform = 'none'; }}
                  onClick={() => openChapter(CHAPTERS.find(c => c.part === part.id))}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
                    <div>
                      <div style={{ color: part.color, fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700, marginBottom: 5, textTransform: 'uppercase', letterSpacing: 1 }}>
                        Part {part.id}
                      </div>
                      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, marginBottom: 4 }}>{part.title}</h3>
                      <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>{part.subtitle}</p>
                    </div>
                    <ProgressRing progress={pct} size={44} color={part.color} />
                  </div>

                  {/* Chapter dots */}
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 14 }}>
                    {partChapters.map(ch => (
                      <div key={ch.id} style={{
                        width: 28, height: 28, borderRadius: '50%',
                        background: progress[ch.id] ? ch.color + '25' : 'var(--bg-elevated)',
                        border: `1px solid ${progress[ch.id] ? ch.color + '60' : 'var(--border)'}`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: 14,
                      }} title={ch.title}>
                        {progress[ch.id] ? <span style={{ color: ch.color, fontSize: 11 }}>✓</span> : <span>{ch.emoji}</span>}
                      </div>
                    ))}
                  </div>

                  <div style={{
                    height: 3, background: 'var(--border)', borderRadius: 2, overflow: 'hidden',
                  }}>
                    <div style={{
                      height: '100%', borderRadius: 2,
                      width: `${pct}%`,
                      background: `linear-gradient(90deg, ${part.color}, ${part.color}aa)`,
                      transition: 'width 0.6s ease',
                    }} />
                  </div>
                  <div style={{ marginTop: 8, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: 11 }}>
                    {done}/{partChapters.length} chapters complete
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── INTERACTIVE TOOLS ────────────────────────── */}
      <section style={{ padding: 'clamp(40px,6vw,80px) clamp(16px,4vw,48px)' }}>
        <div style={{ maxWidth: 'var(--page-max)', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 40 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(24px,3vw,36px)', fontWeight: 900, marginBottom: 10 }}>
              Learn by Doing
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: 15 }}>Four hands-on tools built into every chapter.</p>
          </div>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
            gap: 14,
          }}>
            {[
              { icon: '💻', title: 'Terminal Simulator', desc: 'Run real Git commands in-browser. No setup. No fear.', color: '#51cf66', ch: 5 },
              { icon: '🌿', title: 'Commit Graph', desc: 'Build visual branch/commit graphs interactively.', color: '#4dabf7', ch: 8 },
              { icon: '🎯', title: 'Staging Simulator', desc: 'Drag files between Working Dir → Staging → Commit.', color: '#ffb347', ch: 4 },
              { icon: '🧠', title: 'Quiz Engine', desc: '5 questions per chapter with instant explanations.', color: '#cc5de8', ch: 1 },
            ].map(tool => (
              <div
                key={tool.title}
                onClick={() => openChapter(CHAPTERS.find(c => c.id === tool.ch))}
                style={{
                  background: 'var(--bg-card)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-xl)',
                  padding: 22, cursor: 'pointer',
                  transition: 'all var(--transition-base)',
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = tool.color + '50'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.transform = 'none'; }}
              >
                <div style={{ fontSize: 36, marginBottom: 12 }}>{tool.icon}</div>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 700, marginBottom: 6, color: tool.color }}>
                  {tool.title}
                </h3>
                <p style={{ color: 'var(--text-muted)', fontSize: 13, lineHeight: 1.6 }}>{tool.desc}</p>
                <div style={{ marginTop: 14, color: tool.color, fontFamily: 'var(--font-mono)', fontSize: 11 }}>
                  → Try in Chapter {tool.ch}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── COMMAND REFERENCE ────────────────────────── */}
      <section style={{
        padding: 'clamp(40px,6vw,80px) clamp(16px,4vw,48px)',
        background: 'var(--bg-surface)',
        borderTop: '1px solid var(--border)',
      }}>
        <div style={{ maxWidth: 'var(--page-max)', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 36 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(24px,3vw,36px)', fontWeight: 900, marginBottom: 10 }}>
              Quick Command Reference
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: 15 }}>The commands you'll use every single day.</p>
          </div>

          {/* Category tabs */}
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 24 }}>
            {COMMAND_REFERENCE.map((cat, i) => (
              <button
                key={cat.category}
                onClick={() => setCmdTab(i)}
                style={{
                  background: cmdTab === i ? cat.color + '20' : 'var(--bg-card)',
                  color: cmdTab === i ? cat.color : 'var(--text-muted)',
                  border: `1px solid ${cmdTab === i ? cat.color + '50' : 'var(--border)'}`,
                  borderRadius: 20, padding: '6px 14px',
                  fontFamily: 'var(--font-mono)', fontSize: 12, cursor: 'pointer',
                  transition: 'all var(--transition-fast)',
                }}
              >{cat.category}</button>
            ))}
          </div>

          {/* Command table */}
          {COMMAND_REFERENCE[cmdTab] && (
            <div style={{
              background: 'var(--bg-elevated)', border: '1px solid var(--border)',
              borderRadius: 'var(--radius-lg)', overflow: 'hidden',
              animation: 'fadeIn 0.2s ease',
            }}>
              {COMMAND_REFERENCE[cmdTab].commands.map((cmd, i, arr) => (
                <div key={i} style={{
                  display: 'flex', flexWrap: 'wrap',
                  borderBottom: i < arr.length - 1 ? '1px solid var(--border)' : 'none',
                }}>
                  <div style={{ padding: '13px 18px', minWidth: 230, background: 'var(--bg-card)', borderRight: '1px solid var(--border)' }}>
                    <code style={{ color: COMMAND_REFERENCE[cmdTab].color, fontFamily: 'var(--font-mono)', fontSize: 13 }}>
                      {cmd.cmd}
                    </code>
                  </div>
                  <div style={{ padding: '13px 18px', flex: 1 }}>
                    <span style={{ color: 'var(--text-secondary)', fontSize: 14 }}>{cmd.desc}</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div style={{ textAlign: 'center', marginTop: 20 }}>
            <button onClick={() => setView('cheatsheet')} style={{
              background: 'transparent', border: '1px solid var(--border)',
              color: 'var(--text-muted)', borderRadius: 8, padding: '9px 20px',
              fontFamily: 'var(--font-mono)', fontSize: 12, cursor: 'pointer',
            }}>
              View Full Cheatsheet →
            </button>
          </div>
        </div>
      </section>

      {/* ── FOOTER ───────────────────────────────────── */}
      <footer style={{
        padding: 'clamp(24px,4vw,40px) clamp(16px,4vw,48px)',
        borderTop: '1px solid var(--border)',
        textAlign: 'center',
      }}>
        <div style={{ maxWidth: 'var(--page-max)', margin: '0 auto' }}>
          <div style={{ marginBottom: 12 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 900, color: 'var(--green)' }}>⚡ GitVerse</span>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 8 }}>
            The world's best Git & GitHub guide. Free forever.
          </p>
          <p style={{ color: 'var(--text-muted)', fontSize: 12 }}>
            Built with React · Vite · ❤️
          </p>
        </div>
      </footer>
    </div>
  );
}
